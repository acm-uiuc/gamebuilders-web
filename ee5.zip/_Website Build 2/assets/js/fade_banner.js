$("#banner").fadeTo(0, 0.0);
$(window).ready(function(){
    $("#banner").fadeTo(1000, 1.0);
});

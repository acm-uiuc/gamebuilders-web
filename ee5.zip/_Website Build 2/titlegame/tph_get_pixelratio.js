function get_pixelratio() {
	var pixelRatio = window.devicePixelRatio; 
	return pixelRatio;
}
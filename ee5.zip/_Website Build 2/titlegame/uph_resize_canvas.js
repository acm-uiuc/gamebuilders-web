
function resize_canvas(width, height) {
	var canvas = document.getElementById('canvas');
	var scale = window.devicePixelRatio;
	canvas.style.width = width + "px";
	canvas.style.height = height + "px";
	console.log("AAAAAAAA");
}